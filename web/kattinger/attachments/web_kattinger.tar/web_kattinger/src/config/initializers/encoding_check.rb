module ActionDispatch
    class Request
      class Utils 
        def self.check_param_encoding(params)
        end
      end
    end
  end