package com.springbrut.springbrut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBrutApplication {

  public static void main(String[] args) {
    SpringApplication.run(SpringBrutApplication.class, args);
  }
}
