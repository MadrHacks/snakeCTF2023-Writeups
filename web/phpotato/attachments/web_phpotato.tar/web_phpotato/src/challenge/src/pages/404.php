<?php
// Page init hooks
// Logic handling
http_response_code(404);
// Internal routing
// Render function
$render = fn() => print("Not found");
